# Blood Bank Management System (Core Python)

A beginner-friendly, menu-driven console project built with Core Python and SQLite.

## Features
1. Add donor details
2. View all registered donors
3. Search donors by blood group
4. Record a donation and update inventory
5. View available inventory
6. Submit a blood request (automatically issued if enough demo stock exists; otherwise pending)
7. View request history
8. Automatically process older pending requests when a donation is recorded for that blood group

## Technologies
- Python 3
- SQLite (`sqlite3`, included with Python)
- Object-Oriented Programming

## Requirements
- Python 3.8 or later
- No third-party packages required

## Run the project
1. Download or clone this repository.
2. Open the project folder in VS Code or a terminal.
3. Run:

   ```bash
   python main.py
   ```

4. The program automatically creates `blood_bank.db` and the required tables on first run.

On Windows, if `python` does not work, try `py main.py`.

## Project structure
```text
Blood_Bank_Management_System/
├── main.py
├── README.md
└── .gitignore
```

## Core Python concepts demonstrated
- Variables, strings, integers and input/output
- `if-elif-else` conditional statements
- `while` and `for` loops
- Functions and methods
- Classes and objects
- Tuples and lists
- Exception handling (`try-except`)
- SQLite database connectivity and CRUD operations
- Parameterized SQL queries

## Database tables
- `donors`: donor profile details
- `inventory`: current demo stock for each blood group
- `donations`: donation history
- `blood_requests`: patient requests and their status

## Important project limitation
This is an educational demonstration only. The entered unit values are fictional demo values. It is not a real blood-bank or clinical system and must not be used to determine donor eligibility, blood compatibility, transfusion suitability, storage, or real-world stock availability. Real blood handling requires qualified professionals, approved procedures, testing, traceability and regulatory compliance.
