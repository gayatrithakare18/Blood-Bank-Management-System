import sqlite3
from datetime import date

DB_NAME = "blood_bank.db"
BLOOD_GROUPS = ("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")


class BloodBank:
    """Console-based blood bank system using Python OOP and SQLite."""

    def __init__(self, database=DB_NAME):
        self.database = database
        self.create_tables()

    def connect(self):
        return sqlite3.connect(self.database)

    def create_tables(self):
        with self.connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS donors (
                    donor_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    age INTEGER NOT NULL,
                    phone TEXT NOT NULL,
                    blood_group TEXT NOT NULL,
                    city TEXT NOT NULL
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS inventory (
                    blood_group TEXT PRIMARY KEY,
                    units INTEGER NOT NULL DEFAULT 0
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS donations (
                    donation_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    donor_id INTEGER NOT NULL,
                    units INTEGER NOT NULL,
                    donation_date TEXT NOT NULL,
                    FOREIGN KEY (donor_id) REFERENCES donors(donor_id)
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS blood_requests (
                    request_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    patient_name TEXT NOT NULL,
                    blood_group TEXT NOT NULL,
                    units INTEGER NOT NULL,
                    request_date TEXT NOT NULL,
                    status TEXT NOT NULL
                )
            """)
            for group in BLOOD_GROUPS:
                con.execute(
                    "INSERT OR IGNORE INTO inventory (blood_group, units) VALUES (?, 0)",
                    (group,)
                )

    @staticmethod
    def valid_blood_group(group):
        return group.strip().upper() in BLOOD_GROUPS

    def add_donor(self):
        print("\n--- Add Donor ---")
        name = input("Donor name: ").strip()
        age = self.get_integer("Age: ", minimum=18)
        phone = input("Phone number: ").strip()
        group = input("Blood group (A+, A-, B+, B-, AB+, AB-, O+, O-): ").strip().upper()
        city = input("City: ").strip()

        if not all((name, phone, city)):
            print("Name, phone and city cannot be empty.")
            return
        if not self.valid_blood_group(group):
            print("Invalid blood group.")
            return

        with self.connect() as con:
            cur = con.execute(
                """INSERT INTO donors (name, age, phone, blood_group, city)
                   VALUES (?, ?, ?, ?, ?)""",
                (name, age, phone, group, city)
            )
            print(f"Donor added successfully. Donor ID: {cur.lastrowid}")

    def view_donors(self):
        with self.connect() as con:
            rows = con.execute(
                "SELECT donor_id, name, age, phone, blood_group, city FROM donors ORDER BY donor_id"
            ).fetchall()

        print("\n--- Donor List ---")
        if not rows:
            print("No donor records found.")
            return
        print(f"{'ID':<5} {'NAME':<20} {'AGE':<5} {'PHONE':<15} {'GROUP':<8} CITY")
        print("-" * 75)
        for row in rows:
            print(f"{row[0]:<5} {row[1]:<20} {row[2]:<5} {row[3]:<15} {row[4]:<8} {row[5]}")

    def search_donors(self):
        group = input("Enter blood group to search: ").strip().upper()
        if not self.valid_blood_group(group):
            print("Invalid blood group.")
            return
        with self.connect() as con:
            rows = con.execute(
                """SELECT donor_id, name, age, phone, blood_group, city
                   FROM donors WHERE blood_group = ? ORDER BY name""",
                (group,)
            ).fetchall()

        print(f"\n--- Donors with blood group {group} ---")
        if not rows:
            print("No matching donors found.")
            return
        for donor in rows:
            print(
                f"ID: {donor[0]} | Name: {donor[1]} | Age: {donor[2]} | "
                f"Phone: {donor[3]} | Group: {donor[4]} | City: {donor[5]}"
            )

    def record_donation(self):
        print("\n--- Record Blood Donation ---")
        donor_id = self.get_integer("Donor ID: ", minimum=1)
        units = self.get_integer("Units donated (demo value): ", minimum=1)

        with self.connect() as con:
            donor = con.execute(
                "SELECT donor_id FROM donors WHERE donor_id = ?", (donor_id,)
            ).fetchone()
            if donor is None:
                print("Donor ID not found. Add the donor first.")
                return

            # The blood group is taken from the donor record.
            group = con.execute(
                "SELECT blood_group FROM donors WHERE donor_id = ?", (donor_id,)
            ).fetchone()[0]

            con.execute(
                """INSERT INTO donations (donor_id, units, donation_date)
                   VALUES (?, ?, ?)""",
                (donor_id, units, date.today().isoformat())
            )
            con.execute(
                "UPDATE inventory SET units = units + ? WHERE blood_group = ?",
                (units, group)
            )
            self.process_pending_requests(con, group)

        print(f"Donation recorded. {units} demo unit(s) added to {group} inventory.")

    def view_inventory(self):
        with self.connect() as con:
            rows = con.execute(
                "SELECT blood_group, units FROM inventory ORDER BY blood_group"
            ).fetchall()
        print("\n--- Blood Inventory (demo units) ---")
        for group, units in rows:
            print(f"{group:<5}: {units}")

    def request_blood(self):
        print("\n--- Blood Request ---")
        patient = input("Patient name: ").strip()
        group = input("Required blood group: ").strip().upper()
        units = self.get_integer("Units required (demo value): ", minimum=1)

        if not patient:
            print("Patient name cannot be empty.")
            return
        if not self.valid_blood_group(group):
            print("Invalid blood group.")
            return

        with self.connect() as con:
            available = con.execute(
                "SELECT units FROM inventory WHERE blood_group = ?", (group,)
            ).fetchone()[0]

            if available >= units:
                status = "Issued"
                con.execute(
                    "UPDATE inventory SET units = units - ? WHERE blood_group = ?",
                    (units, group)
                )
            else:
                status = "Pending"

            cur = con.execute(
                """INSERT INTO blood_requests
                   (patient_name, blood_group, units, request_date, status)
                   VALUES (?, ?, ?, ?, ?)""",
                (patient, group, units, date.today().isoformat(), status)
            )
            request_id = cur.lastrowid

        if status == "Issued":
            print(f"Request #{request_id} recorded and marked Issued.")
        else:
            print(f"Request #{request_id} saved as Pending. Available: {available} demo unit(s).")

    @staticmethod
    def process_pending_requests(con, group):
        """Issue oldest pending requests for this group when stock becomes available."""
        pending = con.execute(
            """SELECT request_id, units FROM blood_requests
               WHERE blood_group = ? AND status = 'Pending'
               ORDER BY request_id""",
            (group,)
        ).fetchall()

        for request_id, units in pending:
            available = con.execute(
                "SELECT units FROM inventory WHERE blood_group = ?", (group,)
            ).fetchone()[0]
            if available < units:
                break
            con.execute(
                "UPDATE inventory SET units = units - ? WHERE blood_group = ?",
                (units, group)
            )
            con.execute(
                "UPDATE blood_requests SET status = 'Issued' WHERE request_id = ?",
                (request_id,)
            )

    def view_requests(self):
        with self.connect() as con:
            rows = con.execute(
                """SELECT request_id, patient_name, blood_group, units, request_date, status
                   FROM blood_requests ORDER BY request_id DESC"""
            ).fetchall()
        print("\n--- Blood Requests ---")
        if not rows:
            print("No requests found.")
            return
        print(f"{'ID':<5} {'PATIENT':<20} {'GROUP':<8} {'UNITS':<7} {'DATE':<12} STATUS")
        print("-" * 75)
        for row in rows:
            print(f"{row[0]:<5} {row[1]:<20} {row[2]:<8} {row[3]:<7} {row[4]:<12} {row[5]}")

    @staticmethod
    def get_integer(message, minimum=0):
        while True:
            try:
                value = int(input(message))
                if value < minimum:
                    print(f"Enter a number greater than or equal to {minimum}.")
                    continue
                return value
            except ValueError:
                print("Please enter a valid whole number.")

    @staticmethod
    def show_menu():
        print("""
========== BLOOD BANK MANAGEMENT SYSTEM ==========
1. Add Donor
2. View All Donors
3. Search Donor by Blood Group
4. Record Blood Donation
5. View Blood Inventory
6. Request Blood
7. View Blood Requests
8. Exit
===================================================
""")

    def run(self):
        while True:
            self.show_menu()
            choice = input("Enter your choice (1-8): ").strip()

            if choice == "1":
                self.add_donor()
            elif choice == "2":
                self.view_donors()
            elif choice == "3":
                self.search_donors()
            elif choice == "4":
                self.record_donation()
            elif choice == "5":
                self.view_inventory()
            elif choice == "6":
                self.request_blood()
            elif choice == "7":
                self.view_requests()
            elif choice == "8":
                print("Thank you for using Blood Bank Management System.")
                break
            else:
                print("Invalid choice. Please select 1 to 8.")


if __name__ == "__main__":
    app = BloodBank()
    app.run()
